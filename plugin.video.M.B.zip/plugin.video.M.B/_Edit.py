import xbmcaddon

MainBase = 'https://goo.gl/SgI3fW'
addon = xbmcaddon.Addon('plugin.video.M.B')